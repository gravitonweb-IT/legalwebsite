import React from 'react'

const OpcOnePersonCompanyRegistration = () => {
  return (
    <div>OpcOnePersonCompanyRegistration</div>
  )
}

export default OpcOnePersonCompanyRegistration