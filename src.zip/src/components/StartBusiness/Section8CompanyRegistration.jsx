import React from 'react'

const Section8CompanyRegistration = () => {
  return (
    <div>Section8CompanyRegistration</div>
  )
}

export default Section8CompanyRegistration