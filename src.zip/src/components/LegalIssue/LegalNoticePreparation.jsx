import React from 'react'

const LegalNoticePreparation = () => {
  return (
    <div>LegalNoticePreparation</div>
  )
}

export default LegalNoticePreparation