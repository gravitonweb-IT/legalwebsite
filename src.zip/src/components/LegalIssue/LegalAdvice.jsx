import React from 'react'

const LegalAdvice = () => {
  return (
    <div>LegalAdvice</div>
  )
}

export default LegalAdvice