import React from 'react'

const LegalNoticeReply = () => {
  return (
    <div>LegalNoticeReply</div>
  )
}

export default LegalNoticeReply