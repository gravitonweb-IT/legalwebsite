import React from 'react'

const OnlineAccounting = () => {
  return (
    <div>OnlineAccounting</div>
  )
}

export default OnlineAccounting