import React from 'react'

const ProfessionalTaxRegistration = () => {
  return (
    <div>ProfessionalTaxRegistration</div>
  )
}

export default ProfessionalTaxRegistration