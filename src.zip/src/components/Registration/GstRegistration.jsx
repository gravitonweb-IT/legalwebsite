import React from 'react'

const GstRegistration = () => {
  return (
    <div>GstRegistration</div>
  )
}

export default GstRegistration