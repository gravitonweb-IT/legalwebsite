import React from 'react'

const PfRegistration = () => {
  return (
    <div>PfRegistration</div>
  )
}

export default PfRegistration