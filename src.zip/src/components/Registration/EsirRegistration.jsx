import React from 'react'

const EsirRegistration = () => {
  return (
    <div>EsirRegistration</div>
  )
}

export default EsirRegistration