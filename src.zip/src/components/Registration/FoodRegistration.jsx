import React from 'react'

const FoodRegistration = () => {
  return (
    <div>FoodRegistration</div>
  )
}

export default FoodRegistration