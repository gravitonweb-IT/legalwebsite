import React from 'react'

const GumastaLicense = () => {
  return (
    <div>GumastaLicense</div>
  )
}

export default GumastaLicense