import React from 'react'

const TradeMarkRegistration = () => {
  return (
    <div>TradeMarkRegistration</div>
  )
}

export default TradeMarkRegistration