import React from 'react'

const IcegateRegistration = () => {
  return (
    <div>IcegateRegistration</div>
  )
}

export default IcegateRegistration