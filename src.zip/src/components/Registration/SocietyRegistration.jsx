import React from 'react'

const SocietyRegistration = () => {
  return (
    <div>SocietyRegistration</div>
  )
}

export default SocietyRegistration