import React from 'react'

const TradeLicense = () => {
  return (
    <div>TradeLicense</div>
  )
}

export default TradeLicense