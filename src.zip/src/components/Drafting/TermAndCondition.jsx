import React from 'react'

const TermAndCondition = () => {
  return (
    <div>TermAndCondition</div>
  )
}

export default TermAndCondition