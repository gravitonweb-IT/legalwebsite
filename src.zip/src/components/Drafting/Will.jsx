import React from 'react'

const Will = () => {
  return (
    <div>Will</div>
  )
}

export default Will