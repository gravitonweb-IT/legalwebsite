import React from 'react'

const PrivacyPolicyDrafting = () => {
  return (
    <div>PrivacyPolicyDrafting</div>
  )
}

export default PrivacyPolicyDrafting