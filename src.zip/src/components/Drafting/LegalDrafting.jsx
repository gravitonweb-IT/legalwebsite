import React from 'react'

const LegalDrafting = () => {
  return (
    <div>LegalDrafting</div>
  )
}

export default LegalDrafting