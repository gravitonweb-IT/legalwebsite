import React from 'react'

const ApplicationForm = () => {
  return (
    <div>ApplicationForm</div>
  )
}

export default ApplicationForm