import React from 'react'

const Affidavit = () => {
  return (
    <div>Affidavit</div>
  )
}

export default Affidavit