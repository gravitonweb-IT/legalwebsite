import React from 'react'

const NOC = () => {
  return (
    <div>NOC</div>
  )
}

export default NOC