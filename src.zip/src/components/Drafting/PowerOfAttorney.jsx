import React from 'react'

const PowerOfAttorney = () => {
  return (
    <div>PowerOfAttorney</div>
  )
}

export default PowerOfAttorney