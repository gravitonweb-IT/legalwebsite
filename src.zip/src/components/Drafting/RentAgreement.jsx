import React from 'react'

const RentAgreement = () => {
  return (
    <div>RentAgreement</div>
  )
}

export default RentAgreement