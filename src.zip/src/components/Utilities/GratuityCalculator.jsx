import React from 'react'

const GratuityCalculator = () => {
  return (
    <div>GratuityCalculator</div>
  )
}

export default GratuityCalculator