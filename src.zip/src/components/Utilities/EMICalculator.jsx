import React from 'react'

const EMICalculator = () => {
  return (
    <div>EMICalculator</div>
  )
}

export default EMICalculator