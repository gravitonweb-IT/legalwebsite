import React from 'react'

const GSTCalculator = () => {
  return (
    <div>GSTCalculator</div>
  )
}

export default GSTCalculator