import React from 'react'

const PPfCalculator = () => {
  return (
    <div>PPfCalculator</div>
  )
}

export default PPfCalculator