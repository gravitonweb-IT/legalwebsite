import React from 'react'

const SimpleInterestCalculator = () => {
  return (
    <div>SimpleInterestCalculator</div>
  )
}

export default SimpleInterestCalculator