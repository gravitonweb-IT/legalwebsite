import React from 'react'

const CapitalGainCalculator = () => {
  return (
    <div>CapitalGainCalculator</div>
  )
}

export default CapitalGainCalculator