import React from 'react'

const FDCalculator = () => {
  return (
    <div>FDCalculator</div>
  )
}

export default FDCalculator