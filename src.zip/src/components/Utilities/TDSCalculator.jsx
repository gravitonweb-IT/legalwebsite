import React from 'react'

const TDSCalculator = () => {
  return (
    <div>TDSCalculator</div>
  )
}

export default TDSCalculator