import React from 'react'

const RDCalculator = () => {
  return (
    <div>RDCalculator</div>
  )
}

export default RDCalculator