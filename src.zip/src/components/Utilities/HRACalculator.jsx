import React from 'react'

const HRACalculator = () => {
  return (
    <div>HRACalculator</div>
  )
}

export default HRACalculator