import React from 'react'

const SIPCalculator = () => {
  return (
    <div>SIPCalculator</div>
  )
}

export default SIPCalculator