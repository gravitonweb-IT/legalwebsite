import React from 'react'

const UCalculator = () => {
  return (
    <div>UCalculator</div>
  )
}

export default UCalculator