import React from 'react'

const IncreaseCapitalLlp = () => {
  return (
    <div>IncreaseCapitalLlp</div>
  )
}

export default IncreaseCapitalLlp