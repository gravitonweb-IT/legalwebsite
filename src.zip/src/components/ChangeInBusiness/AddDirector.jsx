import React from 'react'

const AddDirector = () => {
  return (
    <div>AddDirector</div>
  )
}

export default AddDirector