import React from 'react'

const AddPartner = () => {
  return (
    <div>AddPartner</div>
  )
}

export default AddPartner