import React from 'react'

const IncreaseCapitalCompany = () => {
  return (
    <div>IncreaseCapitalCompany</div>
  )
}

export default IncreaseCapitalCompany