import React from 'react'

const RemoveDirector = () => {
  return (
    <div>RemoveDirector</div>
  )
}

export default RemoveDirector