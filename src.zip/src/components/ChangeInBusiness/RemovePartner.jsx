import React from 'react'

const RemovePartner = () => {
  return (
    <div>RemovePartner</div>
  )
}

export default RemovePartner