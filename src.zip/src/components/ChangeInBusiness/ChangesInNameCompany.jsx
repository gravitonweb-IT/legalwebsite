import React from 'react'

const ChangesInNameCompany = () => {
  return (
    <div>ChangesInNameCompany</div>
  )
}

export default ChangesInNameCompany