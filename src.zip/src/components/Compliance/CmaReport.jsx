import React from 'react'

const CmaReport = () => {
  return (
    <div>CmaReport</div>
  )
}

export default CmaReport